# CodeGraph — AI Codebase Knowledge Graph

This repository is being built in phases (per the 15-step Cursor prompt pack).
**This build covers the foundation: authentication, RBAC, and the base
monorepo/infra scaffold** — real, working code, not documentation-only.

## What's actually implemented and runnable here

- **Monorepo**: pnpm workspaces + Turborepo, strict TypeScript throughout.
- **`packages/config`**: Zod-validated environment schema, fails fast on boot.
- **`packages/database`**: Full Prisma schema (users, organizations, RBAC
  roles/permissions, memberships, refresh tokens, repositories, code
  entities/relationships, audit log) + an idempotent seed script.
- **`apps/api`** (NestJS, Clean Architecture — domain/application/infrastructure/presentation per module):
  - `auth` module: register, login, refresh (with rotation + replay-attack
    detection that revokes a whole token family on reuse), logout. Argon2id
    password hashing, JWT access tokens, opaque hashed refresh tokens in an
    `httpOnly`/`secure`/`sameSite=strict` cookie.
  - `iam` module: organization membership management (list/invite/change
    role/remove) enforcing the RBAC permission matrix, with a guardrail that
    blocks demoting or removing the last remaining `OWNER`.
  - Shared cross-cutting concerns: global validation pipe, RFC7807-style
    error responses, structured logging (pino), rate limiting, Helmet, health
    checks (`/health`, `/health/ready`), a composite `@Auth()` decorator that
    chains JWT → org-scope → permission guards correctly every time.
  - **10 passing unit tests** for the auth use-cases (login, register, token
    rotation, replay detection) and the RBAC last-owner guardrails, run
    against in-memory fakes — no database required for these.
- **`apps/web`** (Next.js 15 / React 19): register/login pages, a dashboard
  shell that silently restores a session from the refresh cookie on load, and
  a working members-management page (invite/change role/remove) wired to the
  real API with React Query.
- **`infra/`**: Docker Compose (Postgres, Redis), Nginx reverse-proxy config,
  GitHub Actions CI (type-check, lint, migrate, test, build).

## What's *not* in this build yet

GitHub repo ingestion, AST parsing, Qdrant/embeddings, the LangGraph AI
analysis agent, and the graph visualization UI are Part 2 and Part 3 of the
program (already scoped in detail in the earlier prompt-pack documents) and
will be built the same way — real code, not just docs — in the next pass.

## Important environment note (read this before filing a "Prisma is broken" issue)

This codebase was built and tested in a sandboxed environment whose network
egress only allows a specific domain allow-list — **`binaries.prisma.sh` is
not on it**, so `prisma generate` could not download the query engine binary
here, and `RoleName`-related type errors in `apps/api` are a direct
consequence of that (the Prisma Client types are schema-derived and don't
exist until generation succeeds). Every other part of the codebase —
including all 10 unit tests, which don't touch Prisma — type-checks and runs
cleanly.

**On your own machine or in GitHub Actions this is a non-issue**: those
environments have normal internet access, so
`pnpm --filter @codegraph/database exec prisma generate` will succeed and
every `RoleName`-related error disappears immediately.

## Setup

```bash
# 1. Install dependencies
pnpm install

# 2. Start local infra
docker compose -f infra/docker/docker-compose.yml up -d

# 3. Configure environment
cp apps/api/.env.example apps/api/.env
# Edit apps/api/.env — set a real JWT_ACCESS_SECRET (openssl rand -hex 32)
cp apps/web/.env.example apps/web/.env.local

# 4. Generate the Prisma client and run migrations
pnpm --filter @codegraph/database exec prisma generate
pnpm --filter @codegraph/database exec prisma migrate dev --name init
pnpm --filter @codegraph/database exec prisma db seed

# 5. Run everything
pnpm dev
```

- API: http://localhost:4000 (health check at `/health`)
- Web: http://localhost:3000

## Verifying it end-to-end

1. Go to http://localhost:3000/register, create an account — this creates a
   `User`, a personal `Organization`, and an `OWNER` `Membership` atomically.
2. You're redirected into the dashboard; go to **Members**.
3. Register a second account in an incognito window, then invite that
   second user's email from the first account's Members page with a role —
   confirm the role and the "last owner can't be removed/demoted" guardrail
   both work.
4. Log out and back in — confirm the session survives a page reload via the
   silent refresh flow.

## Tests

```bash
pnpm turbo run test        # unit tests (auth use-cases + RBAC guardrails)
pnpm turbo run type-check  # strict TypeScript across all packages
```
