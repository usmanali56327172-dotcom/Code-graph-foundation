export { getPrismaClient } from './prisma-client';
export * from '@prisma/client';
