import { PrismaClient } from '@prisma/client';

let prismaSingleton: PrismaClient | undefined;

/**
 * Returns a process-wide PrismaClient singleton. Avoids exhausting the
 * Postgres connection pool from repeated instantiation, e.g. across
 * hot-reloaded Nest modules in development.
 */
export function getPrismaClient(): PrismaClient {
  if (!prismaSingleton) {
    prismaSingleton = new PrismaClient({
      log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
    });
  }
  return prismaSingleton;
}

export { PrismaClient } from '@prisma/client';
export * from '@prisma/client';
