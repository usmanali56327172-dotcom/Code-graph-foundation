import { PrismaClient, RoleName } from '@prisma/client';

const prisma = new PrismaClient();

const PERMISSION_KEYS = [
  'organization:update',
  'organization:delete',
  'member:invite',
  'member:remove',
  'member:role:update',
  'repository:connect',
  'repository:delete',
  'repository:read',
  'graph:query',
  'audit:read',
] as const;

type PermissionKey = (typeof PERMISSION_KEYS)[number];

const ROLE_PERMISSIONS: Record<RoleName, PermissionKey[]> = {
  OWNER: [...PERMISSION_KEYS],
  ADMIN: [
    'organization:update',
    'member:invite',
    'member:remove',
    'member:role:update',
    'repository:connect',
    'repository:delete',
    'repository:read',
    'graph:query',
    'audit:read',
  ],
  MAINTAINER: ['repository:connect', 'repository:read', 'graph:query'],
  VIEWER: ['repository:read', 'graph:query'],
};

async function main(): Promise<void> {
  const permissionRecords = await Promise.all(
    PERMISSION_KEYS.map((key) =>
      prisma.permission.upsert({
        where: { key },
        update: {},
        create: { key },
      }),
    ),
  );
  const permissionIdByKey = new Map(permissionRecords.map((p) => [p.key, p.id]));

  for (const roleName of Object.values(RoleName)) {
    const role = await prisma.role.upsert({
      where: { name: roleName },
      update: {},
      create: { name: roleName },
    });

    const keysForRole = ROLE_PERMISSIONS[roleName];
    await Promise.all(
      keysForRole.map((key) => {
        const permissionId = permissionIdByKey.get(key);
        if (!permissionId) {
          throw new Error(`Unknown permission key "${key}" referenced by role "${roleName}"`);
        }
        return prisma.rolePermission.upsert({
          where: { roleId_permissionId: { roleId: role.id, permissionId } },
          update: {},
          create: { roleId: role.id, permissionId },
        });
      }),
    );
  }

  // eslint-disable-next-line no-console
  console.log('Seed complete: roles and permissions are up to date.');
}

main()
  .catch((error) => {
    // eslint-disable-next-line no-console
    console.error('Seed failed:', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
