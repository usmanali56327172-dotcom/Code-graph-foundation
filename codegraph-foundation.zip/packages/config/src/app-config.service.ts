import { Env, parseEnv } from './env.schema';

/**
 * Framework-agnostic config holder. Kept free of Nest decorators here so
 * it can be unit-tested and reused outside apps/api (e.g. from apps/workers
 * in later parts) without pulling in Nest as a dependency of this package.
 * A thin @Injectable() wrapper is provided in apps/api/src/shared/config.
 */
export class AppConfigService {
  private readonly env: Env;

  constructor(source: NodeJS.ProcessEnv = process.env) {
    this.env = parseEnv(source);
  }

  get nodeEnv(): Env['NODE_ENV'] {
    return this.env.NODE_ENV;
  }

  get isProduction(): boolean {
    return this.env.NODE_ENV === 'production';
  }

  get port(): number {
    return this.env.PORT;
  }

  get databaseUrl(): string {
    return this.env.DATABASE_URL;
  }

  get redisUrl(): string {
    return this.env.REDIS_URL;
  }

  get corsOrigins(): string[] {
    return this.env.CORS_ORIGINS;
  }

  get jwt(): { accessSecret: string; accessTtlSeconds: number; refreshTtlDays: number } {
    return {
      accessSecret: this.env.JWT_ACCESS_SECRET,
      accessTtlSeconds: this.env.JWT_ACCESS_TTL_SECONDS,
      refreshTtlDays: this.env.JWT_REFRESH_TTL_DAYS,
    };
  }
}
