'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiClient } from './api-client';
import type { Member, RoleName } from './types';

interface MyOrganization {
  organizationId: string;
  organizationName: string;
  roleName: RoleName;
}

export function useMyOrganizations() {
  return useQuery({
    queryKey: ['my-organizations'],
    queryFn: () => apiClient.get<MyOrganization[]>('/api/v1/iam/me/organizations'),
  });
}

export function useMembers(organizationId: string | undefined) {
  return useQuery({
    queryKey: ['members', organizationId],
    queryFn: () =>
      apiClient.get<Member[]>(`/api/v1/iam/organizations/${organizationId}/members`, {
        'x-organization-id': organizationId ?? '',
      }),
    enabled: Boolean(organizationId),
  });
}

export function useInviteMember(organizationId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: { email: string; role: RoleName }) =>
      apiClient.post<Member>(`/api/v1/iam/organizations/${organizationId}/members`, input, {
        'x-organization-id': organizationId ?? '',
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['members', organizationId] }),
  });
}

export function useUpdateMemberRole(organizationId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: { userId: string; role: RoleName }) =>
      apiClient.patch<Member>(
        `/api/v1/iam/organizations/${organizationId}/members/${input.userId}`,
        { role: input.role },
        { 'x-organization-id': organizationId ?? '' },
      ),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['members', organizationId] }),
  });
}

export function useRemoveMember(organizationId: string | undefined) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (userId: string) =>
      apiClient.delete<{ removed: true }>(`/api/v1/iam/organizations/${organizationId}/members/${userId}`, {
        'x-organization-id': organizationId ?? '',
      }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['members', organizationId] }),
  });
}
