export type RoleName = 'OWNER' | 'ADMIN' | 'MAINTAINER' | 'VIEWER';

export interface AuthResponse {
  accessToken: string;
  organizationId?: string;
}

export interface Member {
  userId: string;
  email: string;
  displayName: string;
  roleName: RoleName;
  joinedAt: string;
}
