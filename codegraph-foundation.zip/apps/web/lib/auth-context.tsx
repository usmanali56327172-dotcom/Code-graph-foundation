'use client';

import { createContext, useContext, useMemo, useState } from 'react';
import { setAccessToken } from './api-client';

interface AuthContextValue {
  organizationId: string | null;
  setSession: (input: { accessToken: string; organizationId?: string }) => void;
  clearSession: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }): React.JSX.Element {
  const [organizationId, setOrganizationId] = useState<string | null>(null);

  const value = useMemo<AuthContextValue>(
    () => ({
      organizationId,
      setSession: (input) => {
        setAccessToken(input.accessToken);
        if (input.organizationId) setOrganizationId(input.organizationId);
      },
      clearSession: () => {
        setAccessToken(null);
        setOrganizationId(null);
      },
    }),
    [organizationId],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider.');
  }
  return context;
}
