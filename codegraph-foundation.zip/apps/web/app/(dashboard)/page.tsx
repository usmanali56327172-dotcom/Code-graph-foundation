export default function DashboardOverviewPage(): React.JSX.Element {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Welcome to CodeGraph</h1>
      <p className="text-sm text-gray-600">
        Your account and organization are set up. Repository connection, ingestion status, and the AI chat panel land
        in the next build phase — this foundation phase covers authentication and team management.
      </p>
    </div>
  );
}
