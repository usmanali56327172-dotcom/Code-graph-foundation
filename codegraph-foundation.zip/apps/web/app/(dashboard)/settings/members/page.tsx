'use client';

import { useState } from 'react';
import {
  useInviteMember,
  useMembers,
  useMyOrganizations,
  useRemoveMember,
  useUpdateMemberRole,
} from '../../../../lib/hooks';
import type { RoleName } from '../../../../lib/types';

const ROLE_OPTIONS: RoleName[] = ['OWNER', 'ADMIN', 'MAINTAINER', 'VIEWER'];
const MANAGE_ROLES: RoleName[] = ['OWNER', 'ADMIN'];

export default function MembersPage(): React.JSX.Element {
  const { data: organizations, isLoading: loadingOrgs } = useMyOrganizations();
  const activeOrg = organizations?.[0];
  const organizationId = activeOrg?.organizationId;
  const canManage = activeOrg ? MANAGE_ROLES.includes(activeOrg.roleName) : false;

  const { data: members, isLoading: loadingMembers } = useMembers(organizationId);
  const inviteMember = useInviteMember(organizationId);
  const updateRole = useUpdateMemberRole(organizationId);
  const removeMember = useRemoveMember(organizationId);

  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<RoleName>('VIEWER');
  const [formError, setFormError] = useState<string | null>(null);

  async function handleInvite(event: React.FormEvent): Promise<void> {
    event.preventDefault();
    setFormError(null);
    try {
      await inviteMember.mutateAsync({ email: inviteEmail, role: inviteRole });
      setInviteEmail('');
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'Failed to invite member.');
    }
  }

  if (loadingOrgs || loadingMembers) {
    return <p className="text-sm text-gray-500">Loading…</p>;
  }

  if (!activeOrg) {
    return <p className="text-sm text-gray-500">You are not part of any organization yet.</p>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Members — {activeOrg.organizationName}</h1>
        <p className="text-sm text-gray-500">Your role: {activeOrg.roleName}</p>
      </div>

      {canManage && (
        <form onSubmit={handleInvite} className="flex flex-wrap items-end gap-3 rounded-md border border-gray-200 p-4">
          <div>
            <label htmlFor="invite-email" className="block text-xs font-medium text-gray-600">
              Email (must already have a CodeGraph account)
            </label>
            <input
              id="invite-email"
              type="email"
              required
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              className="mt-1 rounded-md border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label htmlFor="invite-role" className="block text-xs font-medium text-gray-600">
              Role
            </label>
            <select
              id="invite-role"
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as RoleName)}
              className="mt-1 rounded-md border border-gray-300 px-3 py-2 text-sm"
            >
              {ROLE_OPTIONS.map((role) => (
                <option key={role} value={role}>
                  {role}
                </option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            disabled={inviteMember.isPending}
            className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
          >
            {inviteMember.isPending ? 'Inviting…' : 'Invite'}
          </button>
          {formError && <p className="w-full text-sm text-red-600">{formError}</p>}
        </form>
      )}

      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-gray-200 text-gray-500">
            <th className="py-2">Name</th>
            <th className="py-2">Email</th>
            <th className="py-2">Role</th>
            {canManage && <th className="py-2">Actions</th>}
          </tr>
        </thead>
        <tbody>
          {members?.map((member) => (
            <tr key={member.userId} className="border-b border-gray-100">
              <td className="py-2">{member.displayName}</td>
              <td className="py-2">{member.email}</td>
              <td className="py-2">
                {canManage ? (
                  <select
                    defaultValue={member.roleName}
                    onChange={(e) => updateRole.mutate({ userId: member.userId, role: e.target.value as RoleName })}
                    className="rounded-md border border-gray-300 px-2 py-1 text-sm"
                  >
                    {ROLE_OPTIONS.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                ) : (
                  member.roleName
                )}
              </td>
              {canManage && (
                <td className="py-2">
                  <button
                    onClick={() => removeMember.mutate(member.userId)}
                    className="text-sm text-red-600 hover:underline"
                  >
                    Remove
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
