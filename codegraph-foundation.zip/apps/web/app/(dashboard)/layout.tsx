'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getAccessToken, setAccessToken } from '../../lib/api-client';
import { useAuth } from '../../lib/auth-context';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

export default function DashboardLayout({ children }: { children: React.ReactNode }): React.JSX.Element | null {
  const router = useRouter();
  const { clearSession } = useAuth();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function bootstrap(): Promise<void> {
      if (getAccessToken()) {
        if (!cancelled) setReady(true);
        return;
      }
      // No access token in memory yet (e.g. fresh page load) — attempt a
      // silent refresh using the httpOnly refresh-token cookie.
      try {
        const response = await fetch(`${API_BASE_URL}/api/v1/auth/refresh`, {
          method: 'POST',
          credentials: 'include',
        });
        if (!response.ok) throw new Error('refresh failed');
        const body = (await response.json()) as { accessToken: string };
        setAccessToken(body.accessToken);
        if (!cancelled) setReady(true);
      } catch {
        if (!cancelled) router.replace('/login');
      }
    }

    void bootstrap();
    return () => {
      cancelled = true;
    };
  }, [router]);

  async function handleLogout(): Promise<void> {
    await fetch(`${API_BASE_URL}/api/v1/auth/logout`, { method: 'POST', credentials: 'include' });
    clearSession();
    router.replace('/login');
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-gray-500">Loading your workspace…</div>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <nav className="flex gap-6 text-sm font-medium">
            <Link href="/">Overview</Link>
            <Link href="/settings/members">Members</Link>
          </nav>
          <button onClick={handleLogout} className="text-sm text-gray-500 hover:text-gray-800">
            Log out
          </button>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-8">{children}</main>
    </div>
  );
}
