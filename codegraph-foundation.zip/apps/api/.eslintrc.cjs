module.exports = {
  extends: ['@codegraph/eslint-config'],
  parserOptions: {
    project: './tsconfig.json',
  },
};
