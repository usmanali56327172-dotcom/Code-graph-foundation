import { applyDecorators, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { OrganizationScopeGuard } from '../guards/organization-scope.guard';
import { PermissionsGuard } from '../guards/permissions.guard';
import { RequirePermission } from './require-permission.decorator';

/**
 * Applies the full auth chain in the correct, non-negotiable order:
 * 1. JwtAuthGuard          - verifies the access token, attaches req.user
 * 2. OrganizationScopeGuard - resolves membership for the active org, attaches req.membership
 * 3. PermissionsGuard       - enforces the optional required permission
 *
 * Controllers should never wire these guards individually — doing so risks
 * getting the order wrong (e.g. checking permissions before a membership
 * has even been resolved) and forgetting one entirely.
 *
 * Usage:
 *   @Auth()                          // authenticated + org-scoped, any role
 *   @Auth('member:invite')           // authenticated + org-scoped + permission check
 */
export function Auth(permission?: string): MethodDecorator & ClassDecorator {
  const decorators = [UseGuards(JwtAuthGuard, OrganizationScopeGuard, PermissionsGuard)];
  if (permission) {
    decorators.push(RequirePermission(permission));
  }
  return applyDecorators(...decorators);
}
