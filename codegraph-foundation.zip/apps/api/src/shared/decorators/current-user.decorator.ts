import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { Request } from 'express';

export interface AuthenticatedUser {
  id: string;
  email: string;
}

export interface RequestWithAuth extends Request {
  user?: AuthenticatedUser;
  membership?: {
    organizationId: string;
    roleName: string;
    permissions: string[];
  };
}

export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext): AuthenticatedUser => {
  const request = ctx.switchToHttp().getRequest<RequestWithAuth>();
  if (!request.user) {
    throw new Error('CurrentUser decorator used outside an authenticated route.');
  }
  return request.user;
});
