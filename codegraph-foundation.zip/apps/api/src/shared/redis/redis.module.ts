import { Global, Module, OnModuleDestroy } from '@nestjs/common';
import Redis from 'ioredis';
import { AppConfigService } from '@codegraph/config';

export const REDIS_CLIENT = Symbol('REDIS_CLIENT');

const redisProvider = {
  provide: REDIS_CLIENT,
  useFactory: (config: AppConfigService): Redis => new Redis(config.redisUrl, { lazyConnect: false }),
  inject: [AppConfigService],
};

@Global()
@Module({
  providers: [redisProvider],
  exports: [REDIS_CLIENT],
})
export class RedisModule implements OnModuleDestroy {
  constructor() {}

  async onModuleDestroy(): Promise<void> {
    // Individual injection points close their own references if needed;
    // the shared client is process-scoped and closes on process exit.
  }
}
