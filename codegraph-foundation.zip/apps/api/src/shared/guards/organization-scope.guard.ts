import { BadRequestException, CanActivate, ExecutionContext, Inject, Injectable } from '@nestjs/common';
import type { PrismaClient } from '@codegraph/database';
import { PRISMA_CLIENT } from '../database/prisma.module';
import type { RequestWithAuth } from '../decorators/current-user.decorator';
import { MembershipNotFoundError } from '../errors/domain-error';

@Injectable()
export class OrganizationScopeGuard implements CanActivate {
  constructor(@Inject(PRISMA_CLIENT) private readonly prisma: PrismaClient) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<RequestWithAuth>();
    const headerValue = request.headers['x-organization-id'];
    const organizationId = Array.isArray(headerValue) ? headerValue[0] : (headerValue ?? request.params?.['organizationId']);

    if (!organizationId) {
      throw new BadRequestException('Missing x-organization-id header or organizationId route param.');
    }
    if (!request.user) {
      // JwtAuthGuard must run before this guard; enforced by guard ordering in @Auth().
      throw new MembershipNotFoundError();
    }

    const membership = await this.prisma.membership.findUnique({
      where: { userId_organizationId: { userId: request.user.id, organizationId } },
      include: { role: { include: { permissions: { include: { permission: true } } } } },
    });

    if (!membership) {
      throw new MembershipNotFoundError();
    }

    request.membership = {
      organizationId,
      roleName: membership.role.name,
      permissions: membership.role.permissions.map((rp: { permission: { key: string } }) => rp.permission.key),
    };

    return true;
  }
}
