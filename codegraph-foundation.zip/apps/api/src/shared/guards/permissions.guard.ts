import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PERMISSION_KEY } from '../decorators/require-permission.decorator';
import { InsufficientPermissionError, MembershipNotFoundError } from '../errors/domain-error';
import type { RequestWithAuth } from '../decorators/current-user.decorator';

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredPermission = this.reflector.getAllAndOverride<string | undefined>(PERMISSION_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredPermission) {
      return true; // Route only requires authentication + org scope, no specific permission.
    }

    const request = context.switchToHttp().getRequest<RequestWithAuth>();
    if (!request.membership) {
      throw new MembershipNotFoundError();
    }

    if (!request.membership.permissions.includes(requiredPermission)) {
      throw new InsufficientPermissionError(requiredPermission);
    }

    return true;
  }
}
