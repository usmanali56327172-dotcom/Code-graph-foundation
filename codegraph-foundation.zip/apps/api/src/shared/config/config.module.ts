import { Global, Module } from '@nestjs/common';
import { AppConfigService } from '@codegraph/config';

const configProvider = {
  provide: AppConfigService,
  useFactory: (): AppConfigService => new AppConfigService(process.env),
};

@Global()
@Module({
  providers: [configProvider],
  exports: [AppConfigService],
})
export class ConfigModule {}
