import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus } from '@nestjs/common';
import type { Request, Response } from 'express';
import { DomainError } from './domain-error';
import { AppLogger } from '../logger/app-logger.service';

interface ProblemResponse {
  type: string;
  title: string;
  status: number;
  detail?: string | undefined;
  instance: string;
  requestId?: string | undefined;
}

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  constructor(private readonly logger: AppLogger) {
    this.logger.setContext('AllExceptionsFilter');
  }

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    const problem = this.toProblem(exception, request);
    if (problem.status >= 500) {
      this.logger.error('Unhandled exception', {
        path: request.url,
        requestId: problem.requestId,
        error: exception instanceof Error ? exception.stack : String(exception),
      });
    }

    response.status(problem.status).json(problem);
  }

  private toProblem(exception: unknown, request: Request): ProblemResponse {
    const rawRequestId = request.headers['x-request-id'];
    const requestId = Array.isArray(rawRequestId) ? rawRequestId[0] : rawRequestId;
    const instance = request.originalUrl ?? request.url;

    if (exception instanceof DomainError) {
      return {
        type: `https://codegraph.dev/errors/${exception.code.toLowerCase()}`,
        title: exception.code,
        status: exception.httpStatus,
        detail: exception.message,
        instance,
        requestId,
      };
    }

    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const body = exception.getResponse();
      const detail = typeof body === 'string' ? body : (body as { message?: string }).message;
      return {
        type: 'https://codegraph.dev/errors/http-exception',
        title: HttpStatus[status] ?? 'HTTP_EXCEPTION',
        status,
        detail: Array.isArray(detail) ? detail.join('; ') : detail,
        instance,
        requestId,
      };
    }

    // Never leak internal error details/stack traces to the client.
    return {
      type: 'https://codegraph.dev/errors/internal-server-error',
      title: 'INTERNAL_SERVER_ERROR',
      status: 500,
      detail: 'An unexpected error occurred. Please try again or contact support.',
      instance,
      requestId,
    };
  }
}
