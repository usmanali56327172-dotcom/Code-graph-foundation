/**
 * Base class for errors raised by domain/application layers.
 * These carry no HTTP knowledge — the presentation-layer exception filter
 * (see all-exceptions.filter.ts) maps them to HTTP responses. This keeps
 * the domain layer free of any framework dependency.
 */
export abstract class DomainError extends Error {
  abstract readonly code: string;
  abstract readonly httpStatus: number;

  constructor(message: string) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class InvalidCredentialsError extends DomainError {
  readonly code = 'INVALID_CREDENTIALS';
  readonly httpStatus = 401;

  constructor() {
    super('Invalid email or password.');
  }
}

export class TokenExpiredError extends DomainError {
  readonly code = 'TOKEN_EXPIRED';
  readonly httpStatus = 401;

  constructor() {
    super('The provided token has expired.');
  }
}

export class TokenRevokedError extends DomainError {
  readonly code = 'TOKEN_REVOKED';
  readonly httpStatus = 401;

  constructor() {
    super('The provided token has been revoked.');
  }
}

export class EmailAlreadyRegisteredError extends DomainError {
  readonly code = 'EMAIL_ALREADY_REGISTERED';
  readonly httpStatus = 409;

  constructor() {
    super('An account with this email already exists.');
  }
}

export class OrganizationNotFoundError extends DomainError {
  readonly code = 'ORGANIZATION_NOT_FOUND';
  readonly httpStatus = 404;

  constructor() {
    super('Organization not found or you do not have access to it.');
  }
}

export class InsufficientPermissionError extends DomainError {
  readonly code = 'INSUFFICIENT_PERMISSION';
  readonly httpStatus = 403;

  constructor(permission: string) {
    super(`Missing required permission: ${permission}`);
  }
}

export class MembershipNotFoundError extends DomainError {
  readonly code = 'MEMBERSHIP_NOT_FOUND';
  readonly httpStatus = 404;

  constructor() {
    super('Membership not found.');
  }
}
