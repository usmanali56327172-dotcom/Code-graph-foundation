import { Injectable, Scope } from '@nestjs/common';
import { PinoLogger } from 'nestjs-pino';

/**
 * Thin, explicit wrapper around nestjs-pino so the rest of the codebase
 * depends on this app-owned interface rather than directly on a third-party
 * logging library — keeps a future logger swap a one-file change.
 */
@Injectable({ scope: Scope.TRANSIENT })
export class AppLogger {
  constructor(private readonly pinoLogger: PinoLogger) {}

  setContext(context: string): void {
    this.pinoLogger.setContext(context);
  }

  info(message: string, meta?: Record<string, unknown>): void {
    this.pinoLogger.info(meta ?? {}, message);
  }

  warn(message: string, meta?: Record<string, unknown>): void {
    this.pinoLogger.warn(meta ?? {}, message);
  }

  error(message: string, meta?: Record<string, unknown>): void {
    this.pinoLogger.error(meta ?? {}, message);
  }

  debug(message: string, meta?: Record<string, unknown>): void {
    this.pinoLogger.debug(meta ?? {}, message);
  }
}
