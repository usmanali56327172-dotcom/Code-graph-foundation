import { Global, Module, OnModuleDestroy } from '@nestjs/common';
import { getPrismaClient, PrismaClient } from '@codegraph/database';

export const PRISMA_CLIENT = Symbol('PRISMA_CLIENT');

const prismaProvider = {
  provide: PRISMA_CLIENT,
  useFactory: (): PrismaClient => getPrismaClient(),
};

@Global()
@Module({
  providers: [prismaProvider],
  exports: [PRISMA_CLIENT],
})
export class PrismaModule implements OnModuleDestroy {
  constructor() {}

  async onModuleDestroy(): Promise<void> {
    await getPrismaClient().$disconnect();
  }
}
