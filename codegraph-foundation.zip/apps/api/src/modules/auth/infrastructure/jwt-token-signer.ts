import { Injectable } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { randomBytes, createHash } from 'crypto';
import { AppConfigService } from '@codegraph/config';
import type { AccessTokenClaims, TokenSignerPort } from '../application/ports/auth.ports';

@Injectable()
export class JwtTokenSigner implements TokenSignerPort {
  constructor(private readonly config: AppConfigService) {}

  signAccessToken(claims: AccessTokenClaims): string {
    return jwt.sign(claims, this.config.jwt.accessSecret, {
      expiresIn: this.config.jwt.accessTtlSeconds,
    });
  }

  generateRefreshToken(): string {
    return randomBytes(32).toString('hex'); // 256 bits of entropy
  }

  hashRefreshToken(token: string): string {
    // Refresh tokens are stored hashed, never in plaintext — a DB read
    // alone cannot yield a usable session token.
    return createHash('sha256').update(token).digest('hex');
  }
}
