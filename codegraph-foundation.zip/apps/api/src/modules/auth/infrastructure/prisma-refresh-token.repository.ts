import { Inject, Injectable } from '@nestjs/common';
import type { PrismaClient } from '@codegraph/database';
import { PRISMA_CLIENT } from '../../../shared/database/prisma.module';
import type { RefreshTokenRecord, RefreshTokenRepositoryPort } from '../application/ports/auth.ports';

@Injectable()
export class PrismaRefreshTokenRepository implements RefreshTokenRepositoryPort {
  constructor(@Inject(PRISMA_CLIENT) private readonly prisma: PrismaClient) {}

  async create(input: { userId: string; tokenHash: string; expiresAt: Date }): Promise<RefreshTokenRecord> {
    const created = await this.prisma.refreshToken.create({
      data: { userId: input.userId, tokenHash: input.tokenHash, expiresAt: input.expiresAt },
    });
    return this.toRecord(created);
  }

  async findByTokenHash(tokenHash: string): Promise<RefreshTokenRecord | null> {
    const found = await this.prisma.refreshToken.findUnique({ where: { tokenHash } });
    return found ? this.toRecord(found) : null;
  }

  async revoke(tokenHash: string, replacedByTokenHash?: string): Promise<void> {
    await this.prisma.refreshToken.update({
      where: { tokenHash },
      data: { revokedAt: new Date(), replacedByTokenHash: replacedByTokenHash ?? null },
    });
  }

  async revokeAllForUser(userId: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  private toRecord(record: {
    id: string;
    userId: string;
    tokenHash: string;
    expiresAt: Date;
    revokedAt: Date | null;
  }): RefreshTokenRecord {
    return {
      id: record.id,
      userId: record.userId,
      tokenHash: record.tokenHash,
      expiresAt: record.expiresAt,
      revokedAt: record.revokedAt,
    };
  }
}
