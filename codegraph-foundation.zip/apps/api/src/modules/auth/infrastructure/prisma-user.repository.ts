import { Inject, Injectable } from '@nestjs/common';
import type { PrismaClient, Prisma } from '@codegraph/database';
import { RoleName } from '@codegraph/database';
import { PRISMA_CLIENT } from '../../../shared/database/prisma.module';
import type { AccountCreationRepositoryPort, CreatedAccount, UserRecord, UserRepositoryPort } from '../application/ports/auth.ports';

@Injectable()
export class PrismaUserRepository implements UserRepositoryPort, AccountCreationRepositoryPort {
  constructor(@Inject(PRISMA_CLIENT) private readonly prisma: PrismaClient) {}

  async findByEmail(email: string): Promise<UserRecord | null> {
    const user = await this.prisma.user.findUnique({ where: { email } });
    return user ? this.toRecord(user) : null;
  }

  async findById(id: string): Promise<UserRecord | null> {
    const user = await this.prisma.user.findUnique({ where: { id } });
    return user ? this.toRecord(user) : null;
  }

  async createUserWithPersonalOrganization(input: {
    email: string;
    passwordHash: string;
    displayName: string;
    organizationName: string;
    organizationSlug: string;
  }): Promise<CreatedAccount> {
    return this.prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      const ownerRole = await tx.role.findUnique({ where: { name: RoleName.OWNER } });
      if (!ownerRole) {
        throw new Error('OWNER role is not seeded. Run the database seed script before accepting registrations.');
      }

      const user = await tx.user.create({
        data: {
          email: input.email,
          passwordHash: input.passwordHash,
          displayName: input.displayName,
        },
      });

      const organization = await tx.organization.create({
        data: { name: input.organizationName, slug: input.organizationSlug },
      });

      await tx.membership.create({
        data: { userId: user.id, organizationId: organization.id, roleId: ownerRole.id },
      });

      return { userId: user.id, organizationId: organization.id };
    });
  }

  private toRecord(user: {
    id: string;
    email: string;
    passwordHash: string;
    displayName: string;
    isActive: boolean;
  }): UserRecord {
    return {
      id: user.id,
      email: user.email,
      passwordHash: user.passwordHash,
      displayName: user.displayName,
      isActive: user.isActive,
    };
  }
}
