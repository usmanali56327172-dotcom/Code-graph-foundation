import { Inject, Injectable } from '@nestjs/common';
import {
  AUDIT_LOG,
  PASSWORD_HASHER,
  REFRESH_TOKEN_REPOSITORY,
  TOKEN_SIGNER,
  USER_REPOSITORY,
} from '../../auth.tokens';
import type {
  AuditLogPort,
  PasswordHasherPort,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRepositoryPort,
} from '../ports/auth.ports';
import { InvalidCredentialsError } from '../../../../shared/errors/domain-error';
import { AppConfigService } from '@codegraph/config';

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthTokensResult {
  accessToken: string;
  refreshToken: string;
}

// A constant-shape dummy hash used to run argon2.verify() even when no user
// is found, so "user not found" and "wrong password" take a comparable
// amount of time and cannot be distinguished by a timing side-channel.
const DUMMY_HASH =
  '$argon2id$v=19$m=65536,t=3,p=4$c29tZXNhbHRzb21lc2FsdA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';

@Injectable()
export class LoginUseCase {
  constructor(
    @Inject(USER_REPOSITORY) private readonly userRepository: UserRepositoryPort,
    @Inject(REFRESH_TOKEN_REPOSITORY) private readonly refreshTokenRepository: RefreshTokenRepositoryPort,
    @Inject(PASSWORD_HASHER) private readonly passwordHasher: PasswordHasherPort,
    @Inject(TOKEN_SIGNER) private readonly tokenSigner: TokenSignerPort,
    @Inject(AUDIT_LOG) private readonly auditLog: AuditLogPort,
    private readonly config: AppConfigService,
  ) {}

  async execute(input: LoginInput): Promise<AuthTokensResult> {
    const email = input.email.toLowerCase();
    const user = await this.userRepository.findByEmail(email);

    const passwordMatches = await this.passwordHasher.verify(input.password, user?.passwordHash ?? DUMMY_HASH);

    if (!user || !user.isActive || !passwordMatches) {
      throw new InvalidCredentialsError();
    }

    const accessToken = this.tokenSigner.signAccessToken({ sub: user.id, email: user.email });
    const refreshToken = this.tokenSigner.generateRefreshToken();
    const refreshTokenHash = this.tokenSigner.hashRefreshToken(refreshToken);
    const expiresAt = new Date(Date.now() + this.config.jwt.refreshTtlDays * 24 * 60 * 60 * 1000);

    await this.refreshTokenRepository.create({ userId: user.id, tokenHash: refreshTokenHash, expiresAt });
    await this.auditLog.record({ userId: user.id, action: 'auth.login' });

    return { accessToken, refreshToken };
  }
}
