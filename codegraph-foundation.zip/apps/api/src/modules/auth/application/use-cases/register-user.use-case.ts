import { Inject, Injectable } from '@nestjs/common';
import {
  ACCOUNT_CREATION_REPOSITORY,
  AUDIT_LOG,
  PASSWORD_HASHER,
  REFRESH_TOKEN_REPOSITORY,
  TOKEN_SIGNER,
  USER_REPOSITORY,
} from '../../auth.tokens';
import type {
  AccountCreationRepositoryPort,
  AuditLogPort,
  PasswordHasherPort,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRepositoryPort,
} from '../ports/auth.ports';
import { EmailAlreadyRegisteredError } from '../../../../shared/errors/domain-error';
import { AppConfigService } from '@codegraph/config';

export interface RegisterUserInput {
  email: string;
  password: string;
  displayName: string;
  organizationName: string;
}

export interface AuthTokensResult {
  accessToken: string;
  refreshToken: string;
  organizationId: string;
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .concat('-', Math.random().toString(36).slice(2, 8)); // ensures uniqueness without a DB round-trip
}

@Injectable()
export class RegisterUserUseCase {
  constructor(
    @Inject(USER_REPOSITORY) private readonly userRepository: UserRepositoryPort,
    @Inject(ACCOUNT_CREATION_REPOSITORY) private readonly accountCreationRepository: AccountCreationRepositoryPort,
    @Inject(REFRESH_TOKEN_REPOSITORY) private readonly refreshTokenRepository: RefreshTokenRepositoryPort,
    @Inject(PASSWORD_HASHER) private readonly passwordHasher: PasswordHasherPort,
    @Inject(TOKEN_SIGNER) private readonly tokenSigner: TokenSignerPort,
    @Inject(AUDIT_LOG) private readonly auditLog: AuditLogPort,
    private readonly config: AppConfigService,
  ) {}

  async execute(input: RegisterUserInput): Promise<AuthTokensResult> {
    const existing = await this.userRepository.findByEmail(input.email.toLowerCase());
    if (existing) {
      throw new EmailAlreadyRegisteredError();
    }

    const passwordHash = await this.passwordHasher.hash(input.password);
    const organizationSlug = slugify(input.organizationName);

    const account = await this.accountCreationRepository.createUserWithPersonalOrganization({
      email: input.email.toLowerCase(),
      passwordHash,
      displayName: input.displayName,
      organizationName: input.organizationName,
      organizationSlug,
    });

    const accessToken = this.tokenSigner.signAccessToken({ sub: account.userId, email: input.email.toLowerCase() });
    const refreshToken = this.tokenSigner.generateRefreshToken();
    const refreshTokenHash = this.tokenSigner.hashRefreshToken(refreshToken);

    const expiresAt = new Date(Date.now() + this.config.jwt.refreshTtlDays * 24 * 60 * 60 * 1000);
    await this.refreshTokenRepository.create({ userId: account.userId, tokenHash: refreshTokenHash, expiresAt });

    await this.auditLog.record({
      organizationId: account.organizationId,
      userId: account.userId,
      action: 'auth.register',
      metadata: { email: input.email.toLowerCase() },
    });

    return { accessToken, refreshToken, organizationId: account.organizationId };
  }
}
