import { LoginUseCase } from '../login.use-case';
import { InvalidCredentialsError } from '../../../../../shared/errors/domain-error';
import type {
  AuditLogPort,
  PasswordHasherPort,
  RefreshTokenRecord,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRecord,
  UserRepositoryPort,
} from '../../ports/auth.ports';
import { AppConfigService } from '@codegraph/config';

class FakeUserRepository implements UserRepositoryPort {
  constructor(private readonly users: UserRecord[]) {}
  async findByEmail(email: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.email === email) ?? null;
  }
  async findById(id: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.id === id) ?? null;
  }
}

class FakeRefreshTokenRepository implements RefreshTokenRepositoryPort {
  public created: { userId: string; tokenHash: string; expiresAt: Date }[] = [];
  async create(input: { userId: string; tokenHash: string; expiresAt: Date }): Promise<RefreshTokenRecord> {
    this.created.push(input);
    return { id: 'rt-1', userId: input.userId, tokenHash: input.tokenHash, expiresAt: input.expiresAt, revokedAt: null };
  }
  async findByTokenHash(): Promise<RefreshTokenRecord | null> {
    return null;
  }
  async revoke(): Promise<void> {}
  async revokeAllForUser(): Promise<void> {}
}

class FakePasswordHasher implements PasswordHasherPort {
  async hash(plaintext: string): Promise<string> {
    return `hashed:${plaintext}`;
  }
  async verify(plaintext: string, hash: string): Promise<boolean> {
    return hash === `hashed:${plaintext}`;
  }
}

class FakeTokenSigner implements TokenSignerPort {
  signAccessToken(): string {
    return 'access-token';
  }
  generateRefreshToken(): string {
    return 'refresh-token';
  }
  hashRefreshToken(token: string): string {
    return `hash:${token}`;
  }
}

class FakeAuditLog implements AuditLogPort {
  public entries: { userId?: string; action: string }[] = [];
  async record(input: { userId?: string; action: string }): Promise<void> {
    this.entries.push(input);
  }
}

function buildConfig(): AppConfigService {
  return new AppConfigService({
    DATABASE_URL: 'postgresql://user:pass@localhost:5432/db',
    REDIS_URL: 'redis://localhost:6379',
    JWT_ACCESS_SECRET: 'a'.repeat(32),
  });
}

describe('LoginUseCase', () => {
  it('issues tokens for valid credentials', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'hashed:CorrectHorse123', displayName: 'Ada', isActive: true },
    ]);
    const refreshTokens = new FakeRefreshTokenRepository();
    const auditLog = new FakeAuditLog();
    const useCase = new LoginUseCase(users, refreshTokens, new FakePasswordHasher(), new FakeTokenSigner(), auditLog, buildConfig());

    const result = await useCase.execute({ email: 'ada@example.com', password: 'CorrectHorse123' });

    expect(result.accessToken).toBe('access-token');
    expect(result.refreshToken).toBe('refresh-token');
    expect(refreshTokens.created).toHaveLength(1);
    expect(auditLog.entries).toEqual([{ userId: 'user-1', action: 'auth.login' }]);
  });

  it('rejects an unknown email without revealing whether the account exists', async () => {
    const users = new FakeUserRepository([]);
    const useCase = new LoginUseCase(
      users,
      new FakeRefreshTokenRepository(),
      new FakePasswordHasher(),
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
    );

    await expect(useCase.execute({ email: 'ghost@example.com', password: 'whatever123' })).rejects.toThrow(
      InvalidCredentialsError,
    );
  });

  it('rejects a wrong password with the same error as an unknown email', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'hashed:CorrectHorse123', displayName: 'Ada', isActive: true },
    ]);
    const useCase = new LoginUseCase(
      users,
      new FakeRefreshTokenRepository(),
      new FakePasswordHasher(),
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
    );

    await expect(useCase.execute({ email: 'ada@example.com', password: 'WrongPassword' })).rejects.toThrow(
      InvalidCredentialsError,
    );
  });

  it('rejects a deactivated account even with the correct password', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'hashed:CorrectHorse123', displayName: 'Ada', isActive: false },
    ]);
    const useCase = new LoginUseCase(
      users,
      new FakeRefreshTokenRepository(),
      new FakePasswordHasher(),
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
    );

    await expect(useCase.execute({ email: 'ada@example.com', password: 'CorrectHorse123' })).rejects.toThrow(
      InvalidCredentialsError,
    );
  });
});
