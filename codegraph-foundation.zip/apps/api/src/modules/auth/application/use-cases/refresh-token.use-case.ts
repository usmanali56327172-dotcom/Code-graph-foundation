import { Inject, Injectable } from '@nestjs/common';
import { AUDIT_LOG, REFRESH_TOKEN_REPOSITORY, TOKEN_SIGNER, USER_REPOSITORY } from '../../auth.tokens';
import type {
  AuditLogPort,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRepositoryPort,
} from '../ports/auth.ports';
import { TokenExpiredError, TokenRevokedError } from '../../../../shared/errors/domain-error';
import { AppConfigService } from '@codegraph/config';
import { AppLogger } from '../../../../shared/logger/app-logger.service';

export interface RefreshTokenResult {
  accessToken: string;
  refreshToken: string;
}

@Injectable()
export class RefreshTokenUseCase {
  constructor(
    @Inject(USER_REPOSITORY) private readonly userRepository: UserRepositoryPort,
    @Inject(REFRESH_TOKEN_REPOSITORY) private readonly refreshTokenRepository: RefreshTokenRepositoryPort,
    @Inject(TOKEN_SIGNER) private readonly tokenSigner: TokenSignerPort,
    @Inject(AUDIT_LOG) private readonly auditLog: AuditLogPort,
    private readonly config: AppConfigService,
    private readonly logger: AppLogger,
  ) {
    this.logger.setContext('RefreshTokenUseCase');
  }

  async execute(presentedRefreshToken: string): Promise<RefreshTokenResult> {
    const presentedHash = this.tokenSigner.hashRefreshToken(presentedRefreshToken);
    const existing = await this.refreshTokenRepository.findByTokenHash(presentedHash);

    if (!existing) {
      throw new TokenRevokedError();
    }

    if (existing.revokedAt) {
      // Reuse of a rotated/revoked token: possible token theft. Revoke the
      // entire token family for this user to force re-authentication.
      this.logger.warn('Refresh token reuse detected — revoking all tokens for user', {
        userId: existing.userId,
      });
      await this.refreshTokenRepository.revokeAllForUser(existing.userId);
      await this.auditLog.record({
        userId: existing.userId,
        action: 'auth.refresh_token_reuse_detected',
      });
      throw new TokenRevokedError();
    }

    if (existing.expiresAt.getTime() < Date.now()) {
      throw new TokenExpiredError();
    }

    const user = await this.userRepository.findById(existing.userId);
    if (!user || !user.isActive) {
      throw new TokenRevokedError();
    }

    const newRefreshToken = this.tokenSigner.generateRefreshToken();
    const newRefreshTokenHash = this.tokenSigner.hashRefreshToken(newRefreshToken);
    const expiresAt = new Date(Date.now() + this.config.jwt.refreshTtlDays * 24 * 60 * 60 * 1000);

    await this.refreshTokenRepository.create({ userId: user.id, tokenHash: newRefreshTokenHash, expiresAt });
    await this.refreshTokenRepository.revoke(presentedHash, newRefreshTokenHash);

    const accessToken = this.tokenSigner.signAccessToken({ sub: user.id, email: user.email });

    return { accessToken, refreshToken: newRefreshToken };
  }
}
