import { RefreshTokenUseCase } from '../refresh-token.use-case';
import { TokenExpiredError, TokenRevokedError } from '../../../../../shared/errors/domain-error';
import type {
  AuditLogPort,
  RefreshTokenRecord,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRecord,
  UserRepositoryPort,
} from '../../ports/auth.ports';
import { AppConfigService } from '@codegraph/config';
import { AppLogger } from '../../../../../shared/logger/app-logger.service';

class InMemoryRefreshTokenRepository implements RefreshTokenRepositoryPort {
  private store = new Map<string, RefreshTokenRecord>();
  public revokeAllCalls: string[] = [];

  seed(record: RefreshTokenRecord): void {
    this.store.set(record.tokenHash, record);
  }

  async create(input: { userId: string; tokenHash: string; expiresAt: Date }): Promise<RefreshTokenRecord> {
    const record: RefreshTokenRecord = {
      id: `rt-${this.store.size + 1}`,
      userId: input.userId,
      tokenHash: input.tokenHash,
      expiresAt: input.expiresAt,
      revokedAt: null,
    };
    this.store.set(record.tokenHash, record);
    return record;
  }

  async findByTokenHash(tokenHash: string): Promise<RefreshTokenRecord | null> {
    return this.store.get(tokenHash) ?? null;
  }

  async revoke(tokenHash: string): Promise<void> {
    const record = this.store.get(tokenHash);
    if (record) {
      record.revokedAt = new Date();
    }
  }

  async revokeAllForUser(userId: string): Promise<void> {
    this.revokeAllCalls.push(userId);
    for (const record of this.store.values()) {
      if (record.userId === userId) record.revokedAt = new Date();
    }
  }
}

class FakeUserRepository implements UserRepositoryPort {
  constructor(private readonly users: UserRecord[]) {}
  async findByEmail(email: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.email === email) ?? null;
  }
  async findById(id: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.id === id) ?? null;
  }
}

class FakeTokenSigner implements TokenSignerPort {
  private counter = 0;
  signAccessToken(): string {
    return 'access-token';
  }
  generateRefreshToken(): string {
    this.counter += 1;
    return `refresh-token-${this.counter}`;
  }
  hashRefreshToken(token: string): string {
    return `hash:${token}`;
  }
}

class FakeAuditLog implements AuditLogPort {
  public entries: { userId?: string; action: string }[] = [];
  async record(input: { userId?: string; action: string }): Promise<void> {
    this.entries.push(input);
  }
}

function buildConfig(): AppConfigService {
  return new AppConfigService({
    DATABASE_URL: 'postgresql://user:pass@localhost:5432/db',
    REDIS_URL: 'redis://localhost:6379',
    JWT_ACCESS_SECRET: 'a'.repeat(32),
  });
}

function silentLogger(): AppLogger {
  return new AppLogger({ setContext: () => {}, info: () => {}, warn: () => {}, error: () => {}, debug: () => {} } as never);
}

describe('RefreshTokenUseCase', () => {
  it('rotates a valid, unexpired refresh token', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'x', displayName: 'Ada', isActive: true },
    ]);
    const refreshTokens = new InMemoryRefreshTokenRepository();
    refreshTokens.seed({
      id: 'rt-0',
      userId: 'user-1',
      tokenHash: 'hash:presented-token',
      expiresAt: new Date(Date.now() + 1000 * 60 * 60),
      revokedAt: null,
    });
    const useCase = new RefreshTokenUseCase(
      users,
      refreshTokens,
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
      silentLogger(),
    );

    const result = await useCase.execute('presented-token');

    expect(result.accessToken).toBe('access-token');
    expect(result.refreshToken).toMatch(/^refresh-token-/);
  });

  it('revokes the entire token family when a rotated (already-revoked) token is reused', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'x', displayName: 'Ada', isActive: true },
    ]);
    const refreshTokens = new InMemoryRefreshTokenRepository();
    refreshTokens.seed({
      id: 'rt-0',
      userId: 'user-1',
      tokenHash: 'hash:stolen-token',
      expiresAt: new Date(Date.now() + 1000 * 60 * 60),
      revokedAt: new Date(),
    });
    const useCase = new RefreshTokenUseCase(
      users,
      refreshTokens,
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
      silentLogger(),
    );

    await expect(useCase.execute('stolen-token')).rejects.toThrow(TokenRevokedError);
    expect(refreshTokens.revokeAllCalls).toEqual(['user-1']);
  });

  it('rejects an expired refresh token', async () => {
    const users = new FakeUserRepository([
      { id: 'user-1', email: 'ada@example.com', passwordHash: 'x', displayName: 'Ada', isActive: true },
    ]);
    const refreshTokens = new InMemoryRefreshTokenRepository();
    refreshTokens.seed({
      id: 'rt-0',
      userId: 'user-1',
      tokenHash: 'hash:expired-token',
      expiresAt: new Date(Date.now() - 1000),
      revokedAt: null,
    });
    const useCase = new RefreshTokenUseCase(
      users,
      refreshTokens,
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
      silentLogger(),
    );

    await expect(useCase.execute('expired-token')).rejects.toThrow(TokenExpiredError);
  });

  it('rejects an unknown refresh token', async () => {
    const users = new FakeUserRepository([]);
    const refreshTokens = new InMemoryRefreshTokenRepository();
    const useCase = new RefreshTokenUseCase(
      users,
      refreshTokens,
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
      silentLogger(),
    );

    await expect(useCase.execute('never-issued-token')).rejects.toThrow(TokenRevokedError);
  });
});
