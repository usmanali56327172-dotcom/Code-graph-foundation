import { RegisterUserUseCase } from '../register-user.use-case';
import { EmailAlreadyRegisteredError } from '../../../../../shared/errors/domain-error';
import type {
  AccountCreationRepositoryPort,
  AuditLogPort,
  CreatedAccount,
  PasswordHasherPort,
  RefreshTokenRecord,
  RefreshTokenRepositoryPort,
  TokenSignerPort,
  UserRecord,
  UserRepositoryPort,
} from '../../ports/auth.ports';
import { AppConfigService } from '@codegraph/config';

class FakeUserRepository implements UserRepositoryPort {
  constructor(private readonly users: UserRecord[] = []) {}
  async findByEmail(email: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.email === email) ?? null;
  }
  async findById(id: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.id === id) ?? null;
  }
}

class FakeAccountCreationRepository implements AccountCreationRepositoryPort {
  public calls: Parameters<AccountCreationRepositoryPort['createUserWithPersonalOrganization']>[0][] = [];
  async createUserWithPersonalOrganization(
    input: Parameters<AccountCreationRepositoryPort['createUserWithPersonalOrganization']>[0],
  ): Promise<CreatedAccount> {
    this.calls.push(input);
    return { userId: 'user-1', organizationId: 'org-1' };
  }
}

class FakeRefreshTokenRepository implements RefreshTokenRepositoryPort {
  public created: { userId: string; tokenHash: string; expiresAt: Date }[] = [];
  async create(input: { userId: string; tokenHash: string; expiresAt: Date }): Promise<RefreshTokenRecord> {
    this.created.push(input);
    return { id: 'rt-1', userId: input.userId, tokenHash: input.tokenHash, expiresAt: input.expiresAt, revokedAt: null };
  }
  async findByTokenHash(): Promise<RefreshTokenRecord | null> {
    return null;
  }
  async revoke(): Promise<void> {}
  async revokeAllForUser(): Promise<void> {}
}

class FakePasswordHasher implements PasswordHasherPort {
  async hash(plaintext: string): Promise<string> {
    return `hashed:${plaintext}`;
  }
  async verify(): Promise<boolean> {
    return true;
  }
}

class FakeTokenSigner implements TokenSignerPort {
  signAccessToken(): string {
    return 'access-token';
  }
  generateRefreshToken(): string {
    return 'refresh-token';
  }
  hashRefreshToken(token: string): string {
    return `hash:${token}`;
  }
}

class FakeAuditLog implements AuditLogPort {
  public entries: { organizationId?: string; userId?: string; action: string }[] = [];
  async record(input: { organizationId?: string; userId?: string; action: string }): Promise<void> {
    this.entries.push(input);
  }
}

function buildConfig(): AppConfigService {
  return new AppConfigService({
    DATABASE_URL: 'postgresql://user:pass@localhost:5432/db',
    REDIS_URL: 'redis://localhost:6379',
    JWT_ACCESS_SECRET: 'a'.repeat(32),
  });
}

describe('RegisterUserUseCase', () => {
  it('creates an account, hashes the password, and issues tokens', async () => {
    const userRepository = new FakeUserRepository([]);
    const accountCreation = new FakeAccountCreationRepository();
    const refreshTokens = new FakeRefreshTokenRepository();
    const auditLog = new FakeAuditLog();

    const useCase = new RegisterUserUseCase(
      userRepository,
      accountCreation,
      refreshTokens,
      new FakePasswordHasher(),
      new FakeTokenSigner(),
      auditLog,
      buildConfig(),
    );

    const result = await useCase.execute({
      email: 'Ada@Example.com',
      password: 'CorrectHorse123',
      displayName: 'Ada Lovelace',
      organizationName: 'Analytical Engines Inc',
    });

    expect(result.accessToken).toBe('access-token');
    expect(result.organizationId).toBe('org-1');
    expect(accountCreation.calls[0]?.email).toBe('ada@example.com'); // normalized to lowercase
    expect(accountCreation.calls[0]?.passwordHash).toBe('hashed:CorrectHorse123');
    expect(auditLog.entries).toEqual([
      { organizationId: 'org-1', userId: 'user-1', action: 'auth.register', metadata: { email: 'ada@example.com' } },
    ]);
  });

  it('rejects registration when the email is already in use', async () => {
    const userRepository = new FakeUserRepository([
      { id: 'existing', email: 'ada@example.com', passwordHash: 'x', displayName: 'Ada', isActive: true },
    ]);
    const useCase = new RegisterUserUseCase(
      userRepository,
      new FakeAccountCreationRepository(),
      new FakeRefreshTokenRepository(),
      new FakePasswordHasher(),
      new FakeTokenSigner(),
      new FakeAuditLog(),
      buildConfig(),
    );

    await expect(
      useCase.execute({
        email: 'ada@example.com',
        password: 'CorrectHorse123',
        displayName: 'Ada',
        organizationName: 'Org',
      }),
    ).rejects.toThrow(EmailAlreadyRegisteredError);
  });
});
