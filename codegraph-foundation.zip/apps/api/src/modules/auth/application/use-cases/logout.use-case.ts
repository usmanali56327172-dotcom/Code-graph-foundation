import { Inject, Injectable } from '@nestjs/common';
import { AUDIT_LOG, REFRESH_TOKEN_REPOSITORY, TOKEN_SIGNER } from '../../auth.tokens';
import type { AuditLogPort, RefreshTokenRepositoryPort, TokenSignerPort } from '../ports/auth.ports';

@Injectable()
export class LogoutUseCase {
  constructor(
    @Inject(REFRESH_TOKEN_REPOSITORY) private readonly refreshTokenRepository: RefreshTokenRepositoryPort,
    @Inject(TOKEN_SIGNER) private readonly tokenSigner: TokenSignerPort,
    @Inject(AUDIT_LOG) private readonly auditLog: AuditLogPort,
  ) {}

  async execute(presentedRefreshToken: string, userId?: string): Promise<void> {
    const tokenHash = this.tokenSigner.hashRefreshToken(presentedRefreshToken);
    await this.refreshTokenRepository.revoke(tokenHash);
    await this.auditLog.record({ userId, action: 'auth.logout' });
  }
}
