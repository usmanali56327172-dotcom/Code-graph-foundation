export interface UserRecord {
  id: string;
  email: string;
  passwordHash: string;
  displayName: string;
  isActive: boolean;
}

export interface UserRepositoryPort {
  findByEmail(email: string): Promise<UserRecord | null>;
  findById(id: string): Promise<UserRecord | null>;
}

export interface CreatedAccount {
  userId: string;
  organizationId: string;
}

export interface AccountCreationRepositoryPort {
  /**
   * Creates a User, a personal Organization, and an OWNER Membership
   * atomically. Must be implemented as a single database transaction.
   */
  createUserWithPersonalOrganization(input: {
    email: string;
    passwordHash: string;
    displayName: string;
    organizationName: string;
    organizationSlug: string;
  }): Promise<CreatedAccount>;
}

export interface RefreshTokenRecord {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: Date;
  revokedAt: Date | null;
}

export interface RefreshTokenRepositoryPort {
  create(input: { userId: string; tokenHash: string; expiresAt: Date }): Promise<RefreshTokenRecord>;
  findByTokenHash(tokenHash: string): Promise<RefreshTokenRecord | null>;
  revoke(tokenHash: string, replacedByTokenHash?: string): Promise<void>;
  revokeAllForUser(userId: string): Promise<void>;
}

export interface PasswordHasherPort {
  hash(plaintext: string): Promise<string>;
  verify(plaintext: string, hash: string): Promise<boolean>;
}

export interface AccessTokenClaims {
  sub: string;
  email: string;
}

export interface TokenSignerPort {
  signAccessToken(claims: AccessTokenClaims): string;
  generateRefreshToken(): string;
  hashRefreshToken(token: string): string;
}

export interface AuditLogPort {
  record(input: {
    organizationId?: string | undefined;
    userId?: string | undefined;
    action: string;
    metadata?: Record<string, unknown> | undefined;
  }): Promise<void>;
}
