import { Body, Controller, HttpCode, Post, Req, Res, UnauthorizedException } from '@nestjs/common';
import type { Request, Response } from 'express';
import { Throttle } from '@nestjs/throttler';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { RegisterUserUseCase } from '../application/use-cases/register-user.use-case';
import { LoginUseCase } from '../application/use-cases/login.use-case';
import { RefreshTokenUseCase } from '../application/use-cases/refresh-token.use-case';
import { LogoutUseCase } from '../application/use-cases/logout.use-case';
import { AppConfigService } from '@codegraph/config';

const REFRESH_COOKIE_NAME = 'refresh_token';

interface AccessTokenResponse {
  accessToken: string;
  organizationId?: string;
}

@Controller('api/v1/auth')
export class AuthController {
  constructor(
    private readonly registerUser: RegisterUserUseCase,
    private readonly login: LoginUseCase,
    private readonly refreshToken: RefreshTokenUseCase,
    private readonly logout: LogoutUseCase,
    private readonly config: AppConfigService,
  ) {}

  @Post('register')
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @HttpCode(201)
  async handleRegister(@Body() dto: RegisterDto, @Res({ passthrough: true }) res: Response): Promise<AccessTokenResponse> {
    const result = await this.registerUser.execute(dto);
    this.setRefreshCookie(res, result.refreshToken);
    return { accessToken: result.accessToken, organizationId: result.organizationId };
  }

  @Post('login')
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @HttpCode(200)
  async handleLogin(@Body() dto: LoginDto, @Res({ passthrough: true }) res: Response): Promise<AccessTokenResponse> {
    const result = await this.login.execute(dto);
    this.setRefreshCookie(res, result.refreshToken);
    return { accessToken: result.accessToken };
  }

  @Post('refresh')
  @HttpCode(200)
  async handleRefresh(@Req() req: Request, @Res({ passthrough: true }) res: Response): Promise<AccessTokenResponse> {
    const presentedToken = (req.cookies as Record<string, string | undefined> | undefined)?.[REFRESH_COOKIE_NAME];
    if (!presentedToken) {
      throw new UnauthorizedException('No refresh token present.');
    }
    const result = await this.refreshToken.execute(presentedToken);
    this.setRefreshCookie(res, result.refreshToken);
    return { accessToken: result.accessToken };
  }

  @Post('logout')
  @HttpCode(204)
  async handleLogout(@Req() req: Request, @Res({ passthrough: true }) res: Response): Promise<void> {
    const presentedToken = (req.cookies as Record<string, string | undefined> | undefined)?.[REFRESH_COOKIE_NAME];
    if (presentedToken) {
      await this.logout.execute(presentedToken);
    }
    res.clearCookie(REFRESH_COOKIE_NAME, { path: '/api/v1/auth' });
  }

  private setRefreshCookie(res: Response, token: string): void {
    res.cookie(REFRESH_COOKIE_NAME, token, {
      httpOnly: true,
      secure: this.config.isProduction,
      sameSite: 'strict',
      path: '/api/v1/auth',
      maxAge: this.config.jwt.refreshTtlDays * 24 * 60 * 60 * 1000,
    });
  }
}
