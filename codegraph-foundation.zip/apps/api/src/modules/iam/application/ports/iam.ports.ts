import { RoleName } from '@codegraph/database';

export interface MemberRecord {
  userId: string;
  email: string;
  displayName: string;
  roleName: RoleName;
  joinedAt: Date;
}

export interface MembershipRepositoryPort {
  listByOrganization(organizationId: string): Promise<MemberRecord[]>;
  listOrganizationsForUser(userId: string): Promise<{ organizationId: string; organizationName: string; roleName: RoleName }[]>;
  addMemberByEmail(input: { organizationId: string; email: string; roleName: RoleName }): Promise<MemberRecord>;
  updateRole(input: { organizationId: string; userId: string; roleName: RoleName }): Promise<MemberRecord>;
  remove(input: { organizationId: string; userId: string }): Promise<void>;
  countOwners(organizationId: string): Promise<number>;
  getRole(organizationId: string, userId: string): Promise<RoleName | null>;
}

export interface AuditLogPort {
  record(input: {
    organizationId?: string | undefined;
    userId?: string | undefined;
    action: string;
    metadata?: Record<string, unknown> | undefined;
  }): Promise<void>;
}
