import { Inject, Injectable } from '@nestjs/common';
import { MEMBERSHIP_REPOSITORY } from '../../iam.tokens';
import type { MemberRecord, MembershipRepositoryPort } from '../ports/iam.ports';

@Injectable()
export class ListMembersUseCase {
  constructor(@Inject(MEMBERSHIP_REPOSITORY) private readonly membershipRepository: MembershipRepositoryPort) {}

  async execute(organizationId: string): Promise<MemberRecord[]> {
    return this.membershipRepository.listByOrganization(organizationId);
  }
}
