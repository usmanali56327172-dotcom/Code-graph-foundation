import { Inject, Injectable } from '@nestjs/common';
import { RoleName } from '@codegraph/database';
import { IAM_AUDIT_LOG, MEMBERSHIP_REPOSITORY } from '../../iam.tokens';
import type { AuditLogPort, MemberRecord, MembershipRepositoryPort } from '../ports/iam.ports';

export interface InviteMemberInput {
  organizationId: string;
  invitedByUserId: string;
  email: string;
  roleName: RoleName;
}

@Injectable()
export class InviteMemberUseCase {
  constructor(
    @Inject(MEMBERSHIP_REPOSITORY) private readonly membershipRepository: MembershipRepositoryPort,
    @Inject(IAM_AUDIT_LOG) private readonly auditLog: AuditLogPort,
  ) {}

  async execute(input: InviteMemberInput): Promise<MemberRecord> {
    // Existence/duplicate checks (UserNotRegisteredError, MemberAlreadyExistsError)
    // are enforced inside addMemberByEmail against the live DB state, avoiding
    // a check-then-act race between a separate lookup and the insert.
    const member = await this.membershipRepository.addMemberByEmail({
      organizationId: input.organizationId,
      email: input.email.toLowerCase(),
      roleName: input.roleName,
    });

    await this.auditLog.record({
      organizationId: input.organizationId,
      userId: input.invitedByUserId,
      action: 'member.invite',
      metadata: { invitedEmail: input.email.toLowerCase(), role: input.roleName },
    });

    return member;
  }
}
