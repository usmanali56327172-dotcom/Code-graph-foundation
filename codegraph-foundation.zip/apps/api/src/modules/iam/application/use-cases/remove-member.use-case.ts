import { Inject, Injectable } from '@nestjs/common';
import { RoleName } from '@codegraph/database';
import { IAM_AUDIT_LOG, MEMBERSHIP_REPOSITORY } from '../../iam.tokens';
import type { AuditLogPort, MembershipRepositoryPort } from '../ports/iam.ports';
import { CannotRemoveLastOwnerError } from '../../domain/errors/iam-errors';

export interface RemoveMemberInput {
  organizationId: string;
  actingUserId: string;
  targetUserId: string;
}

@Injectable()
export class RemoveMemberUseCase {
  constructor(
    @Inject(MEMBERSHIP_REPOSITORY) private readonly membershipRepository: MembershipRepositoryPort,
    @Inject(IAM_AUDIT_LOG) private readonly auditLog: AuditLogPort,
  ) {}

  async execute(input: RemoveMemberInput): Promise<void> {
    const currentRole = await this.membershipRepository.getRole(input.organizationId, input.targetUserId);
    if (currentRole === RoleName.OWNER) {
      const ownerCount = await this.membershipRepository.countOwners(input.organizationId);
      if (ownerCount <= 1) {
        throw new CannotRemoveLastOwnerError();
      }
    }

    await this.membershipRepository.remove({ organizationId: input.organizationId, userId: input.targetUserId });

    await this.auditLog.record({
      organizationId: input.organizationId,
      userId: input.actingUserId,
      action: 'member.remove',
      metadata: { targetUserId: input.targetUserId },
    });
  }
}
