import { RoleName } from '@codegraph/database';
import { UpdateMemberRoleUseCase } from '../update-member-role.use-case';
import { RemoveMemberUseCase } from '../remove-member.use-case';
import { CannotRemoveLastOwnerError } from '../../../domain/errors/iam-errors';
import type { AuditLogPort, MemberRecord, MembershipRepositoryPort } from '../../ports/iam.ports';

class FakeMembershipRepository implements MembershipRepositoryPort {
  constructor(
    private roles: Map<string, RoleName>,
    private owners = 1,
  ) {}

  public updateRoleCalls: { userId: string; roleName: RoleName }[] = [];
  public removeCalls: string[] = [];

  async listByOrganization(): Promise<MemberRecord[]> {
    return [];
  }
  async listOrganizationsForUser(): Promise<{ organizationId: string; organizationName: string; roleName: RoleName }[]> {
    return [];
  }
  async addMemberByEmail(): Promise<MemberRecord> {
    throw new Error('not used in this test');
  }
  async updateRole(input: { organizationId: string; userId: string; roleName: RoleName }): Promise<MemberRecord> {
    this.updateRoleCalls.push({ userId: input.userId, roleName: input.roleName });
    return {
      userId: input.userId,
      email: 'member@example.com',
      displayName: 'Member',
      roleName: input.roleName,
      joinedAt: new Date(),
    };
  }
  async remove(input: { userId: string }): Promise<void> {
    this.removeCalls.push(input.userId);
  }
  async countOwners(): Promise<number> {
    return this.owners;
  }
  async getRole(_organizationId: string, userId: string): Promise<RoleName | null> {
    return this.roles.get(userId) ?? null;
  }
}

class FakeAuditLog implements AuditLogPort {
  public entries: unknown[] = [];
  async record(input: unknown): Promise<void> {
    this.entries.push(input);
  }
}

describe('UpdateMemberRoleUseCase', () => {
  it('demotes a non-last owner successfully', async () => {
    const repository = new FakeMembershipRepository(new Map([['user-2', RoleName.OWNER]]), 2);
    const useCase = new UpdateMemberRoleUseCase(repository, new FakeAuditLog());

    await useCase.execute({ organizationId: 'org-1', actingUserId: 'user-1', targetUserId: 'user-2', newRoleName: RoleName.ADMIN });

    expect(repository.updateRoleCalls).toEqual([{ userId: 'user-2', roleName: RoleName.ADMIN }]);
  });

  it('blocks demoting the last remaining owner', async () => {
    const repository = new FakeMembershipRepository(new Map([['user-2', RoleName.OWNER]]), 1);
    const useCase = new UpdateMemberRoleUseCase(repository, new FakeAuditLog());

    await expect(
      useCase.execute({ organizationId: 'org-1', actingUserId: 'user-1', targetUserId: 'user-2', newRoleName: RoleName.ADMIN }),
    ).rejects.toThrow(CannotRemoveLastOwnerError);
    expect(repository.updateRoleCalls).toHaveLength(0);
  });

  it('always allows promoting a member to OWNER', async () => {
    const repository = new FakeMembershipRepository(new Map([['user-2', RoleName.VIEWER]]), 1);
    const useCase = new UpdateMemberRoleUseCase(repository, new FakeAuditLog());

    await useCase.execute({ organizationId: 'org-1', actingUserId: 'user-1', targetUserId: 'user-2', newRoleName: RoleName.OWNER });

    expect(repository.updateRoleCalls).toEqual([{ userId: 'user-2', roleName: RoleName.OWNER }]);
  });
});

describe('RemoveMemberUseCase', () => {
  it('blocks removing the last remaining owner', async () => {
    const repository = new FakeMembershipRepository(new Map([['user-2', RoleName.OWNER]]), 1);
    const useCase = new RemoveMemberUseCase(repository, new FakeAuditLog());

    await expect(useCase.execute({ organizationId: 'org-1', actingUserId: 'user-1', targetUserId: 'user-2' })).rejects.toThrow(
      CannotRemoveLastOwnerError,
    );
    expect(repository.removeCalls).toHaveLength(0);
  });

  it('allows removing a non-owner member', async () => {
    const repository = new FakeMembershipRepository(new Map([['user-2', RoleName.VIEWER]]), 1);
    const useCase = new RemoveMemberUseCase(repository, new FakeAuditLog());

    await useCase.execute({ organizationId: 'org-1', actingUserId: 'user-1', targetUserId: 'user-2' });

    expect(repository.removeCalls).toEqual(['user-2']);
  });
});
