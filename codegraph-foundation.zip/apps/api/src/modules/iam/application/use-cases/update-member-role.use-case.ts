import { Inject, Injectable } from '@nestjs/common';
import { RoleName } from '@codegraph/database';
import { IAM_AUDIT_LOG, MEMBERSHIP_REPOSITORY } from '../../iam.tokens';
import type { AuditLogPort, MemberRecord, MembershipRepositoryPort } from '../ports/iam.ports';
import { CannotRemoveLastOwnerError } from '../../domain/errors/iam-errors';

export interface UpdateMemberRoleInput {
  organizationId: string;
  actingUserId: string;
  targetUserId: string;
  newRoleName: RoleName;
}

@Injectable()
export class UpdateMemberRoleUseCase {
  constructor(
    @Inject(MEMBERSHIP_REPOSITORY) private readonly membershipRepository: MembershipRepositoryPort,
    @Inject(IAM_AUDIT_LOG) private readonly auditLog: AuditLogPort,
  ) {}

  async execute(input: UpdateMemberRoleInput): Promise<MemberRecord> {
    if (input.newRoleName !== RoleName.OWNER) {
      const currentRole = await this.membershipRepository.getRole(input.organizationId, input.targetUserId);
      if (currentRole === RoleName.OWNER) {
        const ownerCount = await this.membershipRepository.countOwners(input.organizationId);
        if (ownerCount <= 1) {
          throw new CannotRemoveLastOwnerError();
        }
      }
    }

    const updated = await this.membershipRepository.updateRole({
      organizationId: input.organizationId,
      userId: input.targetUserId,
      roleName: input.newRoleName,
    });

    await this.auditLog.record({
      organizationId: input.organizationId,
      userId: input.actingUserId,
      action: 'member.role.update',
      metadata: { targetUserId: input.targetUserId, newRole: input.newRoleName },
    });

    return updated;
  }
}
