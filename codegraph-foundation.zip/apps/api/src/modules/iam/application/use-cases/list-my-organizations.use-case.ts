import { Inject, Injectable } from '@nestjs/common';
import { RoleName } from '@codegraph/database';
import { MEMBERSHIP_REPOSITORY } from '../../iam.tokens';
import type { MembershipRepositoryPort } from '../ports/iam.ports';

export interface MyOrganization {
  organizationId: string;
  organizationName: string;
  roleName: RoleName;
}

@Injectable()
export class ListMyOrganizationsUseCase {
  constructor(@Inject(MEMBERSHIP_REPOSITORY) private readonly membershipRepository: MembershipRepositoryPort) {}

  async execute(userId: string): Promise<MyOrganization[]> {
    return this.membershipRepository.listOrganizationsForUser(userId);
  }
}
