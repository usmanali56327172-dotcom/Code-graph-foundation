import { Module } from '@nestjs/common';
import { MembersController } from './presentation/members.controller';
import { MeController } from './presentation/me.controller';
import { ListMembersUseCase } from './application/use-cases/list-members.use-case';
import { ListMyOrganizationsUseCase } from './application/use-cases/list-my-organizations.use-case';
import { InviteMemberUseCase } from './application/use-cases/invite-member.use-case';
import { UpdateMemberRoleUseCase } from './application/use-cases/update-member-role.use-case';
import { RemoveMemberUseCase } from './application/use-cases/remove-member.use-case';
import { PrismaMembershipRepository } from './infrastructure/prisma-membership.repository';
import { PrismaIamAuditLogAdapter } from './infrastructure/prisma-iam-audit-log.adapter';
import { IAM_AUDIT_LOG, MEMBERSHIP_REPOSITORY } from './iam.tokens';

@Module({
  controllers: [MembersController, MeController],
  providers: [
    ListMembersUseCase,
    ListMyOrganizationsUseCase,
    InviteMemberUseCase,
    UpdateMemberRoleUseCase,
    RemoveMemberUseCase,
    { provide: MEMBERSHIP_REPOSITORY, useClass: PrismaMembershipRepository },
    { provide: IAM_AUDIT_LOG, useClass: PrismaIamAuditLogAdapter },
  ],
})
export class IamModule {}
