import { DomainError } from '../../../../shared/errors/domain-error';

export class UserNotRegisteredError extends DomainError {
  readonly code = 'USER_NOT_REGISTERED';
  readonly httpStatus = 404;

  constructor(email: string) {
    super(`No account exists for ${email}. They must register before being added to an organization.`);
  }
}

export class MemberAlreadyExistsError extends DomainError {
  readonly code = 'MEMBER_ALREADY_EXISTS';
  readonly httpStatus = 409;

  constructor() {
    super('This user is already a member of the organization.');
  }
}

export class CannotRemoveLastOwnerError extends DomainError {
  readonly code = 'CANNOT_REMOVE_LAST_OWNER';
  readonly httpStatus = 409;

  constructor() {
    super('An organization must have at least one OWNER. Assign another owner before removing this one.');
  }
}
