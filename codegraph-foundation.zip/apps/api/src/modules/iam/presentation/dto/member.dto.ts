import { IsEmail, IsEnum, MaxLength } from 'class-validator';
import { RoleName } from '@codegraph/database';

export class InviteMemberDto {
  @IsEmail()
  @MaxLength(255)
  email!: string;

  @IsEnum(RoleName)
  role!: RoleName;
}

export class UpdateMemberRoleDto {
  @IsEnum(RoleName)
  role!: RoleName;
}
