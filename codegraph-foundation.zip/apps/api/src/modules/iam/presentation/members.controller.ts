import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { Auth } from '../../../shared/decorators/auth.decorator';
import { CurrentUser } from '../../../shared/decorators/current-user.decorator';
import type { AuthenticatedUser } from '../../../shared/decorators/current-user.decorator';
import { InviteMemberDto, UpdateMemberRoleDto } from './dto/member.dto';
import { ListMembersUseCase } from '../application/use-cases/list-members.use-case';
import { InviteMemberUseCase } from '../application/use-cases/invite-member.use-case';
import { UpdateMemberRoleUseCase } from '../application/use-cases/update-member-role.use-case';
import { RemoveMemberUseCase } from '../application/use-cases/remove-member.use-case';
import type { MemberRecord } from '../application/ports/iam.ports';

@Controller('api/v1/iam/organizations/:organizationId/members')
export class MembersController {
  constructor(
    private readonly listMembers: ListMembersUseCase,
    private readonly inviteMember: InviteMemberUseCase,
    private readonly updateMemberRole: UpdateMemberRoleUseCase,
    private readonly removeMember: RemoveMemberUseCase,
  ) {}

  @Get()
  @Auth()
  async handleList(@Param('organizationId') organizationId: string): Promise<MemberRecord[]> {
    return this.listMembers.execute(organizationId);
  }

  @Post()
  @Auth('member:invite')
  async handleInvite(
    @Param('organizationId') organizationId: string,
    @Body() dto: InviteMemberDto,
    @CurrentUser() currentUser: AuthenticatedUser,
  ): Promise<MemberRecord> {
    return this.inviteMember.execute({
      organizationId,
      invitedByUserId: currentUser.id,
      email: dto.email,
      roleName: dto.role,
    });
  }

  @Patch(':userId')
  @Auth('member:role:update')
  async handleUpdateRole(
    @Param('organizationId') organizationId: string,
    @Param('userId') userId: string,
    @Body() dto: UpdateMemberRoleDto,
    @CurrentUser() currentUser: AuthenticatedUser,
  ): Promise<MemberRecord> {
    return this.updateMemberRole.execute({
      organizationId,
      actingUserId: currentUser.id,
      targetUserId: userId,
      newRoleName: dto.role,
    });
  }

  @Delete(':userId')
  @Auth('member:remove')
  async handleRemove(
    @Param('organizationId') organizationId: string,
    @Param('userId') userId: string,
    @CurrentUser() currentUser: AuthenticatedUser,
  ): Promise<{ removed: true }> {
    await this.removeMember.execute({ organizationId, actingUserId: currentUser.id, targetUserId: userId });
    return { removed: true };
  }
}
