import { Controller, Get, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';
import { CurrentUser } from '../../../shared/decorators/current-user.decorator';
import type { AuthenticatedUser } from '../../../shared/decorators/current-user.decorator';
import { ListMyOrganizationsUseCase, MyOrganization } from '../application/use-cases/list-my-organizations.use-case';

@Controller('api/v1/iam/me')
export class MeController {
  constructor(private readonly listMyOrganizations: ListMyOrganizationsUseCase) {}

  @Get('organizations')
  @UseGuards(JwtAuthGuard)
  async handleListOrganizations(@CurrentUser() user: AuthenticatedUser): Promise<MyOrganization[]> {
    return this.listMyOrganizations.execute(user.id);
  }
}
