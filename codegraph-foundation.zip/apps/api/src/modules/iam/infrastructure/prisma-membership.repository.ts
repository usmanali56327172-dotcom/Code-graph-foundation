import { Inject, Injectable } from '@nestjs/common';
import type { PrismaClient } from '@codegraph/database';
import { RoleName } from '@codegraph/database';
import { PRISMA_CLIENT } from '../../../shared/database/prisma.module';
import type { MemberRecord, MembershipRepositoryPort } from '../application/ports/iam.ports';
import { MemberAlreadyExistsError, UserNotRegisteredError } from '../domain/errors/iam-errors';

@Injectable()
export class PrismaMembershipRepository implements MembershipRepositoryPort {
  constructor(@Inject(PRISMA_CLIENT) private readonly prisma: PrismaClient) {}

  async listByOrganization(organizationId: string): Promise<MemberRecord[]> {
    const memberships = await this.prisma.membership.findMany({
      where: { organizationId },
      include: { user: true, role: true },
      orderBy: { createdAt: 'asc' },
    });
    return memberships.map(
      (m: { userId: string; createdAt: Date; user: { email: string; displayName: string }; role: { name: RoleName } }) =>
        this.toRecord(m),
    );
  }

  async listOrganizationsForUser(
    userId: string,
  ): Promise<{ organizationId: string; organizationName: string; roleName: RoleName }[]> {
    const memberships = await this.prisma.membership.findMany({
      where: { userId },
      include: { organization: true, role: true },
      orderBy: { createdAt: 'asc' },
    });
    return memberships.map(
      (m: { organizationId: string; organization: { name: string }; role: { name: RoleName } }) => ({
        organizationId: m.organizationId,
        organizationName: m.organization.name,
        roleName: m.role.name,
      }),
    );
  }

  async addMemberByEmail(input: { organizationId: string; email: string; roleName: RoleName }): Promise<MemberRecord> {
    const user = await this.prisma.user.findUnique({ where: { email: input.email } });
    if (!user) {
      throw new UserNotRegisteredError(input.email);
    }

    const existing = await this.prisma.membership.findUnique({
      where: { userId_organizationId: { userId: user.id, organizationId: input.organizationId } },
    });
    if (existing) {
      throw new MemberAlreadyExistsError();
    }

    const role = await this.prisma.role.findUniqueOrThrow({ where: { name: input.roleName } });
    const membership = await this.prisma.membership.create({
      data: { userId: user.id, organizationId: input.organizationId, roleId: role.id },
      include: { user: true, role: true },
    });

    return this.toRecord(membership);
  }

  async updateRole(input: { organizationId: string; userId: string; roleName: RoleName }): Promise<MemberRecord> {
    const role = await this.prisma.role.findUniqueOrThrow({ where: { name: input.roleName } });
    const membership = await this.prisma.membership.update({
      where: { userId_organizationId: { userId: input.userId, organizationId: input.organizationId } },
      data: { roleId: role.id },
      include: { user: true, role: true },
    });
    return this.toRecord(membership);
  }

  async remove(input: { organizationId: string; userId: string }): Promise<void> {
    await this.prisma.membership.delete({
      where: { userId_organizationId: { userId: input.userId, organizationId: input.organizationId } },
    });
  }

  async countOwners(organizationId: string): Promise<number> {
    return this.prisma.membership.count({
      where: { organizationId, role: { name: RoleName.OWNER } },
    });
  }

  async getRole(organizationId: string, userId: string): Promise<RoleName | null> {
    const membership = await this.prisma.membership.findUnique({
      where: { userId_organizationId: { userId, organizationId } },
      include: { role: true },
    });
    return membership?.role.name ?? null;
  }

  private toRecord(membership: {
    userId: string;
    createdAt: Date;
    user: { email: string; displayName: string };
    role: { name: RoleName };
  }): MemberRecord {
    return {
      userId: membership.userId,
      email: membership.user.email,
      displayName: membership.user.displayName,
      roleName: membership.role.name,
      joinedAt: membership.createdAt,
    };
  }
}
