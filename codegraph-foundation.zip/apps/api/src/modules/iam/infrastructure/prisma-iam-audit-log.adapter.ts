import { Inject, Injectable } from '@nestjs/common';
import type { PrismaClient } from '@codegraph/database';
import { PRISMA_CLIENT } from '../../../shared/database/prisma.module';
import type { AuditLogPort } from '../application/ports/iam.ports';

@Injectable()
export class PrismaIamAuditLogAdapter implements AuditLogPort {
  constructor(@Inject(PRISMA_CLIENT) private readonly prisma: PrismaClient) {}

  async record(input: {
    organizationId?: string | undefined;
    userId?: string | undefined;
    action: string;
    metadata?: Record<string, unknown> | undefined;
  }): Promise<void> {
    await this.prisma.auditLog.create({
      data: {
        organizationId: input.organizationId,
        userId: input.userId,
        action: input.action,
        metadata: input.metadata as never,
      },
    });
  }
}
